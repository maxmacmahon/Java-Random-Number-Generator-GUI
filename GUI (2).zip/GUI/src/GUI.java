import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import java.util.Random;

public class GUI {

	protected Shell shell;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			GUI window = new GUI();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(622, 446);
		shell.setText("MY GUI");
		
		Label welcomeLabel = new Label(shell, SWT.NONE);
		welcomeLabel.setBounds(54, 10, 149, 20);
		welcomeLabel.setText("Welcome to My GUI");
		
		Label userLabel = new Label(shell, SWT.NONE);
		userLabel.setBounds(54, 50, 335, 30);
		userLabel.setText("Click the left button to generate a random number");
		
		Label numOutput = new Label(shell, SWT.NONE);
		numOutput.setText("Your number is:");
		numOutput.setBounds(54, 209, 175, 38);
		
		Label check = new Label(shell, SWT.NONE);
		check.setBounds(54, 263, 240, 30);
		
		Button numGen = new Button(shell, SWT.NONE);
		
		//Do this when the user selects the number generator
		numGen.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				Random rand = new Random();
				int num = rand.nextInt(100);
				
				try {
					numOutput.setText("Your number is: " + num);
				}
				catch(Exception exe) {
					System.err.println("Error");
					return;
				}
				
				if(num >= 50)
					check.setText("Your number is greater than 50! :D");
				else {
					check.setText("Your number is less than 50 :(");
				}
					
			}
		});
		numGen.setBounds(54, 124, 149, 30);
		numGen.setText("Random Number");
		
		Label lblNewLabel = new Label(shell, SWT.NONE);
		lblNewLabel.setBounds(54, 77, 352, 30);
		lblNewLabel.setText("or click the right button to output a static number.");
		
		Button staticButton = new Button(shell, SWT.NONE);
		
		// Do this when user selects the static button
		staticButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				try {
					numOutput.setText("Your number is: " + 5);
				}
				catch(Exception exe) {
					System.err.println("Error");
					return;
				}
				
				check.setText("Your number is static!");
			}
		});
		
		staticButton.setBounds(260, 124, 149, 30);
		staticButton.setText("Static Number");
	}
}